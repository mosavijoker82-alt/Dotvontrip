# DOTONE RIDER POSTEX 3D V4

Single-file GitHub Pages build. Upload only `index.html` to the repository root. Three.js is loaded from jsDelivr at runtime.
